# Package installation

## Installation of dependencies

**assertr** package

`remotes::install_github("ropensci/assertr@master")`

**data.validator** package

`remotes::install_github("Appsilon/data.validator@master")`

**dqshiny** package

`remotes::install_github("daqana/dqshiny@master")`

## Installation of PolicySimulator

`remotes::install_local(<path-to-unzipped-package>, build_vignettes = TRUE)`

**Note**
Replace `<...>` in the above points with valid paths.

# Documentation

- Preparing the template

```
vignette("template", package = "PolicySimulator")
```

- Generating Policy Simulator app

```
vignette("generating", package = "PolicySimulator")
```

- Running and deployment of Policy Simulator app

```
vignette("application", package = "PolicySimulator")
```


