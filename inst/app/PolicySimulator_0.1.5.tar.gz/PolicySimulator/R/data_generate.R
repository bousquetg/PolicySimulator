#' List of Sheets required in the template
template_data_sheets <- c("Hierarchy", "Data", "Indicator", "Apps", "List")

#' Source template Excel file sheets and export to separate RDS files
#'
#' @param template Template resulting data to be exported
#' @param app_path Path to target application directory
export_template_data <- function(template, app_path) {

  for (data in names(template)) {
    rio::export(template[[data]], glue::glue("{app_path}/src/data/{data}.rds"))
  }
}

#' Import template Excel file sheets as list
#'
#' @param excel_template_path Path to template excel file.
import_template_data <- function(excel_template_path) {
  template <- list()
  for (sheet in template_data_sheets) {
    template[[sheet]] <- readxl::read_excel(excel_template_path, sheet = sheet, na = "")
  }
  return(template)
}

#' Import RDS Simulator base files
#'
#' @param path Path to simulator rds files
import_simulator_data <- function(path = "data") {
  template <- list()
  for (sheet in template_data_sheets) {
    template[[sheet]] <- readRDS(glue::glue("{path}/{sheet}.rds"))
  }
  return(template)
}

#' Convert selected columns to upper values
#'
#' @param data Table object
#' @param columns Columns to convert
convert_to_upper <- function(data, columns = colnames(data)[-1]) {
  dplyr::mutate_at(data, columns, toupper)
}

#' Convert empty string to NA
#' 
#' @param x string
convna <- function(x) {
  if (is.character(x)) {
    x <- ifelse(x == "", NA, x)
  }
  return(x)
}

#' Convert empty cell to NA
#'
#' @param data Table object
convert_empty_to_na <- function(data) {
  dplyr::mutate_all(data, convna)
}

#' Convert selected columns to character
#'
#' @param data Table object
#' @param columns Columns to convert
convert_to_character <- function(data, columns = colnames(data)) {
  dplyr::mutate_at(data, columns, as.character)
}

#' Aggregate level-based scores
#' 
#' The function takes original scores data and levels meta information, and performs 
#' aggregation for all weighted levels that were defined in hierarchy Sheet.
#' 
#' @param aggregation_data Data storing scores, and weights for each hierarchy level.
#' @param levels_meta Hierarchy levels meta information object.
#' @param score_column Name of the column that stores scores to be aggregated.
aggregate_scores <- function(aggregation_data, levels_meta, score_column = "Score") {
  levels <- levels_meta$all
  aggregation_levels <- purrr::map(
    (length(levels) - 1):1,
    ~levels[1:(1 + .)]
  )
  level_score <- function(levels, aggregation_data) {
    if (!last(levels) %in% levels_meta$weighted) {
      return(
        aggregation_data <- aggregation_data %>% 
          dplyr::group_by_at(vars(one_of(levels))) %>%  
          dplyr::mutate(!!sym(score_column) := !!sym(score_column) * !!sym(get_level_col(last(levels), "W"))) %>% 
          dplyr::ungroup()
      )
    } else {
      aggregation_data <- aggregation_data %>% 
        dplyr::group_by_at(vars(one_of(levels))) %>%  
        dplyr::mutate(!!sym(score_column) := !!sym(score_column) * !!sym(get_level_col(last(levels), "W")))
      group_n <- aggregation_data %>% dplyr::summarise(n = n()) %>% dplyr::pull(n)
      
      aggregation_data <- aggregation_data %>% 
        dplyr::summarise_at(vars(score_column, get_level_col(levels[-1], "W")), ~ sum(., na.rm = TRUE))
      aggregation_data$group_n <- group_n
      return(
        aggregation_data %>% 
          dplyr::mutate_at(vars(get_level_col(levels[-1], "W")), ~ . / group_n) %>% 
          dplyr::select(- group_n) %>% 
          dplyr::ungroup()
      )
    }
  }
  aggregations <- aggregation_data
  aggregations_list <- list()
  for (levels in aggregation_levels) {
    aggregations_list[[last(levels)]] <- level_score(levels, aggregations)
    aggregations <- aggregations_list[[last(levels)]]
  }
  aggregations_list
}
