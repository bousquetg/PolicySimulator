#' Shiny end to end tests
#'
#' @name PolicySimulator-package
#' @importFrom magrittr %>% %T>%
#' @importFrom data.table %like%
#' @importFrom dplyr sym vars
NULL
